package src.poiExtractor;

import org.apache.poi.xslf.usermodel.XMLSlideShow;

public interface IPageExtractorToPoi {
	public void extractPageToPoi (XMLSlideShow ppt);
}

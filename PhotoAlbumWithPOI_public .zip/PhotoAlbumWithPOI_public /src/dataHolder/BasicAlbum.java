package dataHolder;

public class BasicAlbum extends Album{

	public BasicAlbum(String title) {
		super(title);
	}

	
}

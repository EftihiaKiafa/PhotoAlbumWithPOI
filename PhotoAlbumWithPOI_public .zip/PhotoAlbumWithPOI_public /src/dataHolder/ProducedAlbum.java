package dataHolder;

public class ProducedAlbum extends Album {
	
	public ProducedAlbum(String keyword) {
			super(keyword);
		}
}
